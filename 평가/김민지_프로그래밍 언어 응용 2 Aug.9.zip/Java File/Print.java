package aug.Test;

public class Print {

	public static void main(String[] args) {
		
		
		Student s1 = new Student();
		Student s2 = new Student ("흥부" ,1);
		
		System.out.println(s1.name);
		System.out.println(s2.name);

		s1.setScore(80);
		
		s1.printResult();
		s2.printResult();
		
		
	}

}
